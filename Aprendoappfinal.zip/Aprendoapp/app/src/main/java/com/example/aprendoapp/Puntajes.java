package com.example.aprendoapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Puntajes extends AppCompatActivity {
    private TextView t_score;
    int score;
    int ultimo_score,puntaje1,puntaje2,puntaje3;
    String string_score;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_puntajes);

        t_score = (TextView)findViewById(R.id.text_score);
        string_score = getIntent().getStringExtra("score");
        score = Integer.parseInt(string_score);
        t_score.setText("Score: " + score);
        /*carga el antiguo puntaje*/

        SharedPreferences preferences = getSharedPreferences("PREFS",0);
        ultimo_score = preferences.getInt("ultimo_score",0);
        puntaje1 = preferences.getInt("puntaje1",0);
        puntaje2 = preferences.getInt("puntaje2",0);
        puntaje3 = preferences.getInt("puntaje3",0);

        /*Metodo de Ordenamiento Burbuja*/
        if(ultimo_score > puntaje3){
            puntaje3=ultimo_score;
            SharedPreferences.Editor editor = preferences.edit();
            editor.putInt("puntaje3", puntaje3);
            editor.apply();;
        }

        if(ultimo_score > puntaje2) {
            int aux = puntaje2;
            puntaje2=ultimo_score;
            puntaje3=aux;
            SharedPreferences.Editor editor = preferences.edit();
            editor.putInt("puntaje3", puntaje3);
            editor.putInt("puntaje2", puntaje2);
            editor.apply();;
        }
        if(ultimo_score > puntaje1) {
            int aux = puntaje1;
            puntaje1=ultimo_score;
            puntaje2=aux;
            SharedPreferences.Editor editor = preferences.edit();
            editor.putInt("puntaje2", puntaje2);
            editor.putInt("puntaje1", puntaje1);
            editor.apply();;
        }

        t_score.setText("Ultimo Score:" + ultimo_score  + "\n" +
                 "Primer lugar" + puntaje1 + "\n" +
                "Segundo lugar" + puntaje2 + "\n" +
                "Tercer lugar" + puntaje3 + "\n");


        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.ic_launcher);

        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "BD", null,1);
        SQLiteDatabase BD = admin.getWritableDatabase();

    }


   @Override
   public void onBackPressed(){
       Intent intent = new Intent(getApplicationContext(),MainActivity.class);
       startActivity(intent);
       finish();
   }
}