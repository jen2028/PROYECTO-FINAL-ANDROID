package com.example.aprendoapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText nombre;
    private ImageView personaje;
    private TextView bestscore;
    int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre = (EditText) findViewById(R.id.nombre);
        personaje = (ImageView) findViewById(R.id.imageView_personaje);
        bestscore = (TextView) findViewById(R.id.puntaje);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.ic_launcher);


        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "BD", null, 1);
        SQLiteDatabase BD = admin.getWritableDatabase();

         Cursor consulta = BD.rawQuery( "select * from puntaje where score = (select max(score) from puntaje)", null);
         if(consulta.moveToFirst()){
             String temp_nombre = consulta.getString(0);
             String temp_score = consulta.getString(1);
             bestscore.setText("Record " + temp_score + "de " + temp_nombre);
             BD.close();

         } else  {
             BD.close();
         }


    }

    public void Jugar (View view){

        String nom = nombre.getText().toString();
            if(!nom.equals("")){
                Intent intent =new Intent(this, Nivel1.class);
                intent.putExtra("jugador",  nom);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "No olvides escribir tu nombre", Toast.LENGTH_SHORT).show();
                nombre.requestFocus();
                InputMethodManager  imm = (InputMethodManager)getSystemService(this.INPUT_METHOD_SERVICE);
                imm.showSoftInput(nombre, InputMethodManager.SHOW_IMPLICIT);
            }



    }
    public void Puntajes(View view){
        SharedPreferences preferences = getSharedPreferences("PREFS",0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("ultimo_score",score);
        editor.apply();
        Intent intent =new Intent(this, Puntajes.class);
        startActivity(intent);
        finish();

    }

    @Override
    public void onBackPressed(){

    }

}