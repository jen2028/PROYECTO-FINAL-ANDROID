package com.example.aprendoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Nivel3 extends AppCompatActivity {

    private TextView t_nombre, t_score;
    private ImageView num_uno, num_dos, ima_vidas;
    private EditText respuesta;
    int score , numrandom_uno, numrandom_dos, resultado, vidas = 3;
    String nombre_jugador, string_score, string_vidas;
    String numero[] = {"cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve"};


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nivel3);

        Toast.makeText(this, "Nivel 3 Multiplicacion", Toast.LENGTH_SHORT).show();
        t_nombre = (TextView)findViewById(R.id.text_nombre);
        t_score = (TextView)findViewById(R.id.text_score);
        ima_vidas = (ImageView) findViewById(R.id.Vidas);
        num_uno = (ImageView)findViewById(R.id.numero_uno);
        num_dos = (ImageView) findViewById(R.id.numero_dos);
        respuesta= (EditText)findViewById(R.id.text_resultado);

        nombre_jugador = getIntent().getStringExtra("jugador");
        t_nombre.setText("Jugador:  " +nombre_jugador);

        string_score = getIntent().getStringExtra("score");
        score = Integer.parseInt(string_score);
        t_score.setText("Score: " + score);

        string_vidas = getIntent().getStringExtra("vidas");
        vidas = Integer.parseInt(string_vidas);

        if (vidas == 3){
            ima_vidas.setImageResource(R.drawable.trescorazones);
        }if (vidas == 2){
            ima_vidas.setImageResource(R.drawable.doscorazones);
        }if (vidas == 1){
            ima_vidas.setImageResource(R.drawable.corazon);
        }

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.ic_launcher);
        Numrandom();
    }

    public void Compara(View view){
        String resp = respuesta.getText().toString();
        if (!resp.equals("")){

            int resp_jugador = Integer.parseInt(resp);
            if(resultado == resp_jugador){

                score++;
                t_score.setText("Score:  "+ score);
                respuesta.setText("");
                BaseDeDatos();

            }else {
                vidas--;
                BaseDeDatos();

                switch (vidas){
                    case 3:
                        ima_vidas.setImageResource(R.drawable.trescorazones);
                        break;
                    case 2:
                        Toast.makeText(this, "te quedan 2 vidas", Toast.LENGTH_SHORT).show();
                        ima_vidas.setImageResource(R.drawable.doscorazones);
                        break;
                    case 1:
                        Toast.makeText(this, "te queda 1 vida", Toast.LENGTH_SHORT).show();
                        ima_vidas.setImageResource(R.drawable.corazon);
                        break;
                    case 0:
                        Toast.makeText(this, "GAME OVER :c ", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(this, Gameover.class);
                        startActivity(intent);
                        finish();
                        break;
                }
                respuesta.setText("");

            }
            Numrandom();

        }else {
            Toast.makeText(this, "Escribe tu respuesta", Toast.LENGTH_SHORT).show();
        }
    }
    public void Numrandom(){
        if(score <= 29){
            numrandom_uno= (int) (Math.random() * 10);
            numrandom_dos = (int) (Math.random() * 10);
            resultado = numrandom_uno * numrandom_dos;

            if(resultado >= 0){
                for(int i=0; i < numero.length; i++){
                    int id =getResources().getIdentifier(numero[i], "drawable", getPackageName());
                    if(numrandom_uno == i){
                        num_uno.setImageResource(id);
                    }
                    if(numrandom_dos == i){
                        num_dos.setImageResource(id);
                    }
                }

            }else{
                Numrandom();
            }

        }else {
            Intent intent = new Intent(this, Nivel4.class);

            string_score = String.valueOf(score);
            string_vidas = String.valueOf(vidas);
            intent.putExtra("jugador",nombre_jugador);
            intent.putExtra("score", string_score);
            intent.putExtra("vidas", string_vidas);
            startActivity(intent);
            finish();
        }
    }

    public void BaseDeDatos(){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "BD", null,1);
        SQLiteDatabase BD = admin.getWritableDatabase();

        Cursor consulta = BD.rawQuery("select * from puntaje where score = (select max (score) from puntaje)", null);
        if(consulta.moveToFirst()){
            String temp_nombre = consulta.getString(0);
            String temp_score = consulta.getString(1);
            int mejorscore = Integer.parseInt(temp_score);

            if(score > mejorscore){
                ContentValues modificacion = new ContentValues();
                modificacion.put("nombre", nombre_jugador);
                modificacion.put("score", score);

                BD.update("puntaje", modificacion, "score=" + mejorscore, null);

            }

        }else{
            ContentValues insertar = new ContentValues();
            insertar.put("nombre", nombre_jugador);
            insertar.put("score", score);
            BD.insert("puntaje", null, insertar);
        }
        BD.close();

    }
    @Override
    public void onBackPressed(){
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
        finish();
    }
}